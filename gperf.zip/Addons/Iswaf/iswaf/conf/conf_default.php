<?php

return array('defences'=>array(
				'webshell'=>'On',
				'upload'=>'On',
				'webserver'=>'On',
				'inject'=>'On',	
				'filemode'=>'On',
				'server_args'=>'On',
				'hotfixs'=>'On',
				'callback_xss'=>'On',
				'denier'=>array('notice'=>'deny.')
				)
		);
					 
?>