<?php
 define('iswaf_connenct_key','5a17847748477a665e322c45a62ac51f');
 define('iswaf_connenct_api','http://www.fanghuyun.com/client.php');
 ?>