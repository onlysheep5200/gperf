<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013 http://www.onethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: zhuyajie <xcoolcc@gmail.com>
// +----------------------------------------------------------------------

namespace Admin\Model;
use Think\Model;
/**
 * 权限规则模型
 * @author 朱亚杰 <zhuyajie@topthink.net>
 */
class AuthRuleModel extends Model{
    
    const RULE_URL = 1;
    const RULE_MAIN = 2;

}
