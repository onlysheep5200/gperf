<?php
    define('DB_HOST','localhost');
    define('DB_USER','root');
    define('DB_PWD','');
    define('DB_NAME','gperf');
    define('APP_DEBUG',TRUE);
    //define('APP_PATH','/var/www/html/GPerf/Application/');
   // define('RUNTIME_PATH','/var/www/html/GPerf/Runtime/');
   // require '/var/www/html/GPerf/ThinkPHP/ThinkPHP.php';
?>
