import json
rtn = dict(pid='12345',result='lalalalalalalalalala')
print json.dumps(rtn)
